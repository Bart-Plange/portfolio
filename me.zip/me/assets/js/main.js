// initiate parallax effects
var scene = document.getElementById('scene');
var parallaxInstance = new Parallax(scene);
// you can change parallax options using parallaxInstance